﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Bitmon
    {
        // Define the Warriors properties
        public string Name { get; set; } = "Bitmon";
        public double Health { get; set; } = 0;
        public double Attk1 { get; set; } = 0;
        public double Attk2 { get; set; } = 0;
        public double Attk3 { get; set; } = 0;
        public double Attk4 { get; set; } = 0;
        public double Pp1 { get; set; } = 0;
        public double Pp2 { get; set; } = 0;
        public double Pp3 { get; set; } = 0;
        public double Pp4 { get; set; } = 0;
        public double BlockMax { get; set; } = 0;

        // Always create a single Random instance and reuse
        // it or you will get the same value over and over
        Random rnd = new Random();

        // Constructor initializes the warrior
        public Bitmon(string name = "Bitmon",
            double health = 0,
            double attk1 = 0,
            double attk2 = 0,
            double attk3 = 0,
            double attk4 = 0,
            double blockMax = 0,
            double pp1 = 0,
            double pp2 = 0,
            double pp3 = 0,
            double pp4 = 0)


        {
            Name = name;
            Health = health;
            Attk1 = attk1;
            Attk2 = attk2;
            Attk3 = attk3;
            Attk4 = attk4;
            BlockMax = blockMax;
            Pp1 = pp1;
            Pp2 = pp2;
            Pp3 = pp3;
            Pp4 = pp4;
        }

        // Generate a random atack value from 1
        // to the warriors maximum attack value
        public double Attack()
        {

            bool continueloop = true;
            do
            {
                Console.WriteLine("{0} to choose your attack, press 1,2,3,or 4 /n press 5 to pass", Name);
                string chooseattack = Console.ReadLine();
                if (chooseattack == "1")
                {

                    Pp1 -= 1;
                    if (Pp1 >= 0)
                    {
                        return rnd.Next(1, (int)Attk1);

                    }
                    else
                    {

                        Console.WriteLine("------not enough pp, use another move-----");
                        continueloop = false;
                    }

                }
                if (chooseattack == "2")
                {

                    if (Pp2 > 0)
                    {
                        Pp2 -= 1;
                        return rnd.Next(1, (int)Attk2);
                    }
                    else
                    {

                        Console.WriteLine("-----not enough pp, use another move-----");
                        continueloop = false;
                    }

                }
                if (chooseattack == "3")
                {

                    if (Pp3 > 0)
                    {
                        Pp3 -= 1;
                        return rnd.Next(1, (int)Attk3);
                    }
                    else
                    {
                        Console.WriteLine("-----not enough pp, use another move-----");
                        continueloop = false;

                    }

                }
                if (chooseattack == "4")
                {

                    if (Pp4 > 0)
                    {
                        Pp4 -= 1;
                        return rnd.Next(1, (int)Attk1);

                    }
                    else
                    {

                        Console.WriteLine("-----not enough pp, use another move-----");
                        continueloop = false;
                    }

                }
                if (chooseattack == "5")
                {
                    return 0;
                }
                else return 0;



            } while (continueloop == true);



        }

        // Generate a random block value from
        // 1 to the warriors maximum block
        public double Block()
        {
            return rnd.Next(1, (int)BlockMax);
        }
    }
}
