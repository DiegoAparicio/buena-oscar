﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Player
    {
        public string Nombre { get; set; } = "jugador";
        public double Vida { get; set; } = 0;


        public Player(string nombre = "jugador",
            double vida = 0)
        {
            Nombre = nombre;
            Vida = vida;

        }
        public double Life()
        {
            return Vida;
        }
    }
}
