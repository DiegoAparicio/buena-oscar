﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Battle
    {
        // This is a utility class so it makes sense
        // to have just static methods


        // Recieve both Warrior objects
        public static void StartFight(Bitmon bitmon1,
            Bitmon bitmon2)
        {
            // Loop giving each Warrior a chance to attack
            // and block each turn until 1 dies
            while (true)
            {
                if (GetAttackResult(bitmon1, bitmon2) == "Game Over")
                {
                    Console.WriteLine("Game Over");
                    break;
                }

                if (GetAttackResult(bitmon2, bitmon1) == "Game Over")
                {
                    Console.WriteLine("Game Over");
                    break;
                }
            }
        }

        // Accept 2 Warriors
        public static string GetAttackResult(Bitmon bitmonA,
            Bitmon bitmonB)
        {
            // Calculate one Warriors attack and the others block
            double warAAttkAmt = bitmonA.Attack();
            double warBBlkAmt = bitmonB.Block();


            // Subtract block from attack
            double dmg2WarB = warAAttkAmt - warBBlkAmt;

            // If there was damage subtract that from the health



            if (dmg2WarB > 0)
            {
                bitmonB.Health = bitmonB.Health - dmg2WarB;
            }
            else dmg2WarB = 0;

            // Print out info on who attacked who and for how
            // much damage
            Console.WriteLine("{0} Attacks {1} and Deals {2} Damage",
                bitmonA.Name,
                bitmonB.Name,
                dmg2WarB);

            // Provide output on the change to health
            Console.WriteLine("{0} Has {1} Health\n",
                bitmonB.Name,
                bitmonB.Health);

            // Check if the warriors health fell below
            // zero and if so print a message and send
            // a response that will end the loop
            if (bitmonB.Health <= 0)
            {
                Console.WriteLine("{0} has Died and {1} is Victorious\n",
                    bitmonB.Name,
                    bitmonA.Name);


                return "second fight";
            }
            else return "Fight Again";
        }
    }
}
