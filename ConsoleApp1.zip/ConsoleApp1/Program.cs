﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("player1, name yourself");

            Player player1 = new Player(Console.ReadLine(), 2);
            Console.WriteLine("player2, name yourself");
            Player player2 = new Player(Console.ReadLine(), 2);
            Console.WriteLine("{0}, name your fighter", player1.Nombre);
            Bitmon fighter1 = new Bitmon(Console.ReadLine(), 200, 50, 80, 60, 70, 40, 2, 2, 2, 2);
            Console.WriteLine("{0} stats are: \n health={1} \n attack1 = {2}dmg // {7}pp \n attack2 = {3}dmg // {8}pp \n attack3 = {4}dmg // {8}pp \n attack4 = {5}dmg // {9}pp \n defense = {6}", fighter1.Name, fighter1.Health, fighter1.Attk1, fighter1.Attk2, fighter1.Attk3, fighter1.Attk4, fighter1.BlockMax, fighter1.Pp1, fighter1.Pp2, fighter1.Pp3, fighter1.Pp4);
            Console.WriteLine("{0}, name your fighter", player2.Nombre);
            Bitmon fighter2 = new Bitmon(Console.ReadLine(), 200, 70, 50, 60, 80, 40, 2, 2, 2, 2);
            Console.WriteLine("{0} stats are: \n health={1} \n attack1 = {2}dmg // {7}pp \n attack2 = {3}dmg // {8}pp \n attack3 = {4}dmg // {8}pp \n attack4 = {5}dmg // {9}pp \n defense = {6}", fighter2.Name, fighter2.Health, fighter2.Attk1, fighter2.Attk2, fighter2.Attk3, fighter2.Attk4, fighter2.BlockMax, fighter2.Pp1, fighter2.Pp2, fighter2.Pp3, fighter2.Pp4);
            Battle.StartFight(fighter1, fighter2);


            Console.ReadLine();
        }

    }
}
