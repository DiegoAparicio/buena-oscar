﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class FabricaBitmons
    {
        private static Bitmon Crear(int number, Move move1, Move move2, Move move3, Move move4)
        {
            return Bitmon.Builder.Init(number)
                .Move1(move1)
                .Move2(move2)
                .Move3(move3)
                .Move4(move4)
                .Create();
        }
    }
        public static Bitmon PrimeCup(int number)
        {
            switch (number)
            {
            case 1: // Charmon
                return Create(1, new ThunderShock(), new Spark(), new Ember(), new FlameThrower());

            case 2: // Bitmeleon
                return Create(2, new Ember(), new Firefang(), new FireSpin(), new Flamethrower());

            case 3: // Pikamon
                return Create(3, new ChargeBeam(), new VoltSwitch(), new FireFang(), new FireSpin());

            case 4: // Qwertymon
                return Create(4, new ThunderShock(), new Spark(), new ChargeBeam(), new VoltSwitch());

            case 5: // Squimon
                return Create(5, new FrostBreath(), new PowderSnow(), new Bubble(), new WaterFall());

            case 6: // Worbimon
                return Create(6, new WaterGun(), new PoisonGun(), new Bubble(), new Waterfall());

            case 7: // Icemon
                return Create(7, new PoisonGun(), new IceShard(), new Hypothermia(), new WaterGun());

            case 8: // Dragonice
                return Create(8, new IceShard(), new FrostBreath(), new PowderSnow(), new Hypothermia());

            case 9: // Tirimon
                return Create(9, new FlameThrower(), new Hypothermia(), new PoisonGun(), new Spark());

            case 10: // Naidormon
                return Create(10, new FireSpin(), new IceShard(), WaterFall(), VoltSwitch());

            default: throw new ArgumentException("The given index " + number + " is an invalid pokemon number");
        }
            
        }
}
